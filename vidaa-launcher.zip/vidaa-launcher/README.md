# VIDAA TV Launcher

A remote-friendly home page of web apps for Hisense/VIDAA TVs. VIDAA can't install
APKs or custom apps, but its built-in browser can open any web app. This gives you
one bookmark with big, arrow-key-navigable tiles for all of them.

## 1. Host it (free, ~3 minutes)
1. Create a GitHub repo (e.g. `tv`), upload `index.html` and `.nojekyll`.
2. Repo **Settings → Pages → Deploy from branch → main / root → Save**.
3. Your launcher URL: `https://YOUR-USERNAME.github.io/tv/`

## 2. Add your apps
Edit the `APPS` list near the top of `index.html` (name, emoji, URL).
For Jellyfin/Plex/Emby on your own server, use its local address.

## 3. Put it on the TV
1. Open the TV's **Browser** (Home → Apps → Web Browser).
2. Enter your launcher URL, then bookmark it / set it as the homepage.
3. Open it any time and pick a tile.

## Limits
- Only apps with a TV-friendly web version work. DRM services (Netflix, Disney+, Prime)
  usually don't play in the TV browser; use the VIDAA Store versions of those.
- Typing is slow with a remote; the Hisense phone app (RemoteNOW) has a keyboard.
- Real installable PWAs on VIDAA are possible with the community project
  "Vidaa-Edge" (https://vidaa.flummi.ch). It's experimental and unofficial: read its
  README and use it at your own risk.
